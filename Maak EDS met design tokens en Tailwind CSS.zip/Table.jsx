import React from 'react';
import PropTypes from 'prop-types';

/**
 * Table Component
 * 
 * Een flexibele tabel component met header, body en optionele striping.
 * 
 * @component
 * @example
 * <Table>
 *   <Table.Header>
 *     <Table.Row>
 *       <Table.HeaderCell>Naam</Table.HeaderCell>
 *       <Table.HeaderCell>Email</Table.HeaderCell>
 *     </Table.Row>
 *   </Table.Header>
 *   <Table.Body>
 *     <Table.Row>
 *       <Table.Cell>Jan Bakker</Table.Cell>
 *       <Table.Cell>jan@example.com</Table.Cell>
 *     </Table.Row>
 *   </Table.Body>
 * </Table>
 */
const Table = ({
  children,
  striped = true,
  hoverable = true,
  className = '',
  ...props
}) => {
  const baseClasses = 'w-full border-collapse';
  
  const classes = `
    ${baseClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className="overflow-x-auto">
      <table className={classes} {...props}>
        {children}
      </table>
    </div>
  );
};

/**
 * Table Header Component
 */
const TableHeader = ({
  children,
  className = '',
  ...props
}) => {
  return (
    <thead className={`bg-secondary-dark text-white ${className}`.trim()} {...props}>
      {children}
    </thead>
  );
};

/**
 * Table Body Component
 */
const TableBody = ({
  children,
  className = '',
  ...props
}) => {
  return (
    <tbody className={className} {...props}>
      {children}
    </tbody>
  );
};

/**
 * Table Row Component
 */
const TableRow = ({
  children,
  hoverable = true,
  striped = false,
  className = '',
  ...props
}) => {
  const hoverClasses = hoverable ? 'hover:bg-gray-50 transition-colors' : '';
  
  const classes = `
    border-b border-gray-200
    ${hoverClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <tr className={classes} {...props}>
      {children}
    </tr>
  );
};

/**
 * Table Header Cell Component
 */
const TableHeaderCell = ({
  children,
  align = 'left',
  className = '',
  ...props
}) => {
  const alignClasses = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };
  
  const classes = `
    px-6 py-3 text-sm font-semibold uppercase tracking-wider
    ${alignClasses[align] || alignClasses.left}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <th className={classes} {...props}>
      {children}
    </th>
  );
};

/**
 * Table Cell Component
 */
const TableCell = ({
  children,
  align = 'left',
  className = '',
  ...props
}) => {
  const alignClasses = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };
  
  const classes = `
    px-6 py-4 text-sm text-gray-900
    ${alignClasses[align] || alignClasses.left}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <td className={classes} {...props}>
      {children}
    </td>
  );
};

Table.Header = TableHeader;
Table.Body = TableBody;
Table.Row = TableRow;
Table.HeaderCell = TableHeaderCell;
Table.Cell = TableCell;

Table.propTypes = {
  children: PropTypes.node.isRequired,
  striped: PropTypes.bool,
  hoverable: PropTypes.bool,
  className: PropTypes.string,
};

TableHeader.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

TableBody.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

TableRow.propTypes = {
  children: PropTypes.node.isRequired,
  hoverable: PropTypes.bool,
  striped: PropTypes.bool,
  className: PropTypes.string,
};

TableHeaderCell.propTypes = {
  children: PropTypes.node.isRequired,
  align: PropTypes.oneOf(['left', 'center', 'right']),
  className: PropTypes.string,
};

TableCell.propTypes = {
  children: PropTypes.node.isRequired,
  align: PropTypes.oneOf(['left', 'center', 'right']),
  className: PropTypes.string,
};

export default Table;

