import React from 'react';
import PropTypes from 'prop-types';

/**
 * Stat Card Component
 * 
 * Een card component voor statistieken met een gekleurde accent border.
 * 
 * @component
 * @example
 * <StatCard
 *   value="€8,450"
 *   label="Openstaande Commissie"
 *   subtext="Volgende uitbetaling: 15 nov"
 *   badge="12.5%"
 *   accentColor="teal"
 * />
 */
const StatCard = ({
  value,
  label,
  subtext,
  badge,
  badgeVariant = 'success',
  accentColor = 'teal',
  className = '',
  ...props
}) => {
  const baseClasses = 'bg-white rounded-lg shadow-md p-6 border-l-4';
  
  const accentColorMap = {
    teal: 'border-l-primary-teal',
    green: 'border-l-success',
    dark: 'border-l-secondary-dark',
    red: 'border-l-error',
    blue: 'border-l-primary-blue',
    warning: 'border-l-warning',
  };
  
  const badgeVariantClasses = {
    success: 'bg-success-50 text-success-700',
    warning: 'bg-warning-50 text-warning-700',
    error: 'bg-error-50 text-error-700',
    neutral: 'bg-gray-100 text-gray-700',
  };
  
  const classes = `
    ${baseClasses}
    ${accentColorMap[accentColor] || accentColorMap.teal}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className={classes} {...props}>
      {badge && (
        <div className="mb-2">
          <span className={`inline-block px-2 py-1 text-xs font-semibold rounded ${badgeVariantClasses[badgeVariant]}`}>
            {badge}
          </span>
        </div>
      )}
      <p className="text-sm text-gray-500 uppercase tracking-wide mb-2">
        {label}
      </p>
      <p className="text-4xl font-bold text-gray-900 mb-1">
        {value}
      </p>
      {subtext && (
        <p className="text-sm text-gray-500">
          {subtext}
        </p>
      )}
    </div>
  );
};

StatCard.propTypes = {
  /** De hoofdwaarde die wordt weergegeven */
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  /** Label/beschrijving van de statistiek */
  label: PropTypes.string.isRequired,
  /** Optionele subtekst onder de waarde */
  subtext: PropTypes.string,
  /** Badge tekst (bijv. percentage) */
  badge: PropTypes.string,
  /** Variant van de badge */
  badgeVariant: PropTypes.oneOf(['success', 'warning', 'error', 'neutral']),
  /** Kleur van de accent border */
  accentColor: PropTypes.oneOf(['teal', 'green', 'dark', 'red', 'blue', 'warning']),
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default StatCard;

