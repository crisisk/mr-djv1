import React from 'react';
import PropTypes from 'prop-types';

/**
 * Input Component
 * 
 * Een formulier input component met label, error handling en verschillende states.
 * 
 * @component
 * @example
 * <Input
 *   label="E-mailadres"
 *   type="email"
 *   value={email}
 *   onChange={handleChange}
 *   error="Ongeldig e-mailadres"
 * />
 */
const Input = ({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  error,
  helpText,
  required = false,
  disabled = false,
  fullWidth = true,
  className = '',
  id,
  name,
  ...props
}) => {
  const inputId = id || name || `input-${Math.random().toString(36).substr(2, 9)}`;
  
  const baseClasses = 'px-3 py-2 text-base border rounded-lg transition-all focus:outline-none focus:ring-2';
  
  const stateClasses = error
    ? 'border-error focus:ring-error focus:border-transparent'
    : 'border-gray-300 focus:ring-primary-teal focus:border-transparent';
  
  const disabledClasses = disabled
    ? 'bg-gray-100 cursor-not-allowed opacity-60'
    : 'bg-white';
  
  const widthClasses = fullWidth ? 'w-full' : '';
  
  const inputClasses = `
    ${baseClasses}
    ${stateClasses}
    ${disabledClasses}
    ${widthClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className={fullWidth ? 'w-full' : ''}>
      {label && (
        <label
          htmlFor={inputId}
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {label}
          {required && <span className="text-error ml-1">*</span>}
        </label>
      )}
      <input
        id={inputId}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        required={required}
        className={inputClasses}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={error ? `${inputId}-error` : helpText ? `${inputId}-help` : undefined}
        {...props}
      />
      {error && (
        <p id={`${inputId}-error`} className="text-sm text-error mt-1">
          {error}
        </p>
      )}
      {helpText && !error && (
        <p id={`${inputId}-help`} className="text-sm text-gray-500 mt-1">
          {helpText}
        </p>
      )}
    </div>
  );
};

Input.propTypes = {
  /** Label voor het input veld */
  label: PropTypes.string,
  /** Type van het input veld */
  type: PropTypes.string,
  /** Waarde van het input veld */
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  /** Change handler functie */
  onChange: PropTypes.func,
  /** Placeholder tekst */
  placeholder: PropTypes.string,
  /** Error bericht */
  error: PropTypes.string,
  /** Help tekst */
  helpText: PropTypes.string,
  /** Of het veld verplicht is */
  required: PropTypes.bool,
  /** Of het veld disabled is */
  disabled: PropTypes.bool,
  /** Of het veld de volledige breedte moet innemen */
  fullWidth: PropTypes.bool,
  /** Extra CSS classes */
  className: PropTypes.string,
  /** ID van het input element */
  id: PropTypes.string,
  /** Name attribuut */
  name: PropTypes.string,
};

export default Input;

