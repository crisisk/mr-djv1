import React from 'react';
import PropTypes from 'prop-types';

/**
 * Sidebar Component
 * 
 * Een sidebar navigatie component met menu items en user profile.
 * 
 * @component
 * @example
 * <Sidebar title="SEVENSA">
 *   <Sidebar.Item active icon={<DashboardIcon />}>
 *     Dashboard
 *   </Sidebar.Item>
 *   <Sidebar.Item icon={<SettingsIcon />}>
 *     Settings
 *   </Sidebar.Item>
 * </Sidebar>
 */
const Sidebar = ({
  children,
  title,
  userProfile,
  className = '',
  ...props
}) => {
  const classes = `
    bg-secondary-dark text-white w-64 min-h-screen flex flex-col
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <aside className={classes} {...props}>
      {title && (
        <div className="px-6 py-4 text-xl font-bold border-b border-gray-700">
          {title}
        </div>
      )}
      <nav className="py-4 flex-1">
        {children}
      </nav>
      {userProfile && (
        <div className="px-6 py-4 border-t border-gray-700">
          {userProfile}
        </div>
      )}
    </aside>
  );
};

/**
 * Sidebar Item Component
 */
const SidebarItem = ({
  children,
  active = false,
  icon,
  onClick,
  href,
  className = '',
  ...props
}) => {
  const baseClasses = 'flex items-center px-6 py-3 transition-colors cursor-pointer';
  
  const stateClasses = active
    ? 'bg-success text-white'
    : 'text-gray-300 hover:bg-gray-700 hover:text-white';
  
  const classes = `
    ${baseClasses}
    ${stateClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  const content = (
    <>
      {icon && <span className="mr-3 flex-shrink-0">{icon}</span>}
      <span>{children}</span>
    </>
  );
  
  if (href) {
    return (
      <a href={href} className={classes} {...props}>
        {content}
      </a>
    );
  }
  
  return (
    <div className={classes} onClick={onClick} {...props}>
      {content}
    </div>
  );
};

/**
 * Sidebar User Profile Component
 */
const SidebarUserProfile = ({
  name,
  role,
  avatar,
  className = '',
  ...props
}) => {
  return (
    <div className={`flex items-center ${className}`.trim()} {...props}>
      {avatar && (
        <div className="w-10 h-10 rounded-full bg-primary-teal flex items-center justify-center text-white font-semibold mr-3 flex-shrink-0">
          {avatar}
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">{name}</p>
        {role && <p className="text-xs text-gray-400 truncate">{role}</p>}
      </div>
    </div>
  );
};

Sidebar.Item = SidebarItem;
Sidebar.UserProfile = SidebarUserProfile;

Sidebar.propTypes = {
  children: PropTypes.node.isRequired,
  title: PropTypes.string,
  userProfile: PropTypes.node,
  className: PropTypes.string,
};

SidebarItem.propTypes = {
  children: PropTypes.node.isRequired,
  active: PropTypes.bool,
  icon: PropTypes.node,
  onClick: PropTypes.func,
  href: PropTypes.string,
  className: PropTypes.string,
};

SidebarUserProfile.propTypes = {
  name: PropTypes.string.isRequired,
  role: PropTypes.string,
  avatar: PropTypes.node,
  className: PropTypes.string,
};

export default Sidebar;

