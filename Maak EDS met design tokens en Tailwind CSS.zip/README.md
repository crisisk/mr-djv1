# Enterprise Design System (EDS)

Dit document beschrijft het Enterprise Design System (EDS) dat is ontwikkeld op basis van de verstrekte designpresentaties. Het systeem is ontworpen om consistentie, efficiëntie en schaalbaarheid te bieden voor de ontwikkeling van frontend-applicaties.

Het EDS is gebouwd op een fundament van **design tokens**, geïmplementeerd met **Tailwind CSS**, en bevat een bibliotheek van vooraf gedefinieerde componentstijlen.

## Inhoudsopgave

1.  [Structuur van het Systeem](#structuur-van-het-systeem)
2.  [Kerncomponenten](#kerncomponenten)
    *   [Design Tokens](#design-tokens)
    *   [Tailwind CSS Configuratie](#tailwind-css-configuratie)
    *   [Globale CSS & Componenten](#globale-css--componenten)
    *   [CSS Variabelen](#css-variabelen)
3.  [Installatie en Gebruik](#installatie-en-gebruik)
4.  [Overzicht van Design Tokens](#overzicht-van-design-tokens)
    *   [Kleuren](#kleuren)
    *   [Typografie](#typografie)
    *   [Spacing](#spacing)
    *   [Andere Tokens](#andere-tokens)

---

## Structuur van het Systeem

Het EDS is georganiseerd in de volgende bestanden, die allemaal zijn opgenomen in de bijgevoegde `EDS_Assets.zip`:

| Bestand                | Beschrijving                                                                                                                            |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| `design-tokens.json`   | Een gestandaardiseerd JSON-bestand dat alle design tokens definieert (kleuren, typografie, spacing, etc.). Dit is de "single source of truth". |
| `tailwind.config.js`   | De configuratie voor Tailwind CSS, die de design tokens uitbreidt en toepast op het framework.                                           |
| `styles.css`           | Het hoofd-CSS-bestand dat Tailwind importeert en een bibliotheek van `@layer components` definieert voor herbruikbare componentstijlen.      |
| `variables.css`        | Een CSS-bestand dat alle design tokens als CSS Custom Properties (variabelen) definieert voor gebruik buiten het Tailwind-ecosysteem.       |
| `package.json`         | Definieert de benodigde `devDependencies` (zoals Tailwind CSS) en scripts om de CSS te bouwen.                                            |
| `design_analysis.md`   | Een gedetailleerde analyse van de designelementen die uit de verstrekte presentaties zijn geëxtraheerd.                                 |

## Kerncomponenten

### Design Tokens (`design-tokens.json`)

Dit bestand is de kern van het design system. Het bevat een gestructureerde definitie van alle visuele designelementen, zoals kleuren, lettertypen, spacing, schaduwen en breakpoints. Het gebruik van een gestandaardiseerd formaat maakt het mogelijk om deze tokens programmatisch te lezen en te converteren naar verschillende formaten (CSS, JavaScript, etc.).

### Tailwind CSS Configuratie (`tailwind.config.js`)

Deze configuratie integreert de gedefinieerde design tokens direct in Tailwind CSS. De `theme.extend` sectie is uitgebreid met de specifieke kleuren, lettergroottes, spacing-units en andere waarden van het EDS. Dit stelt ontwikkelaars in staat om de design system-conforme stijlen toe te passen met behulp van de vertrouwde utility classes van Tailwind.

```javascript
// Voorbeeld uit tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          teal: '#00A896',
          blue: '#007BFF',
        },
        // ... andere kleuren
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
      },
      // ... andere tokens
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
}
```

### Globale CSS & Componenten (`styles.css`)

Dit bestand dient twee doelen:
1.  **Importeren van Tailwind**: Het importeert de `base`, `components`, en `utilities` van Tailwind.
2.  **Component Layer**: Het definieert een set van herbruikbare component-classes met `@apply`. Dit bevordert consistentie en vermindert de noodzaak om lange reeksen utility classes in de HTML te herhalen. Voorbeelden zijn `.btn`, `.card`, `.alert`, en `.form-input`.

```css
/* Voorbeeld van een component-stijl */
@layer components {
  .btn-primary {
    @apply inline-flex items-center justify-center px-4 py-2 text-base font-semibold rounded transition-all duration-200 \
           bg-primary-teal text-white hover:bg-primary-teal/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-teal;
  }
}
```

### CSS Variabelen (`variables.css`)

Voor scenario's waarin het gebruik van Tailwind-classes niet mogelijk of wenselijk is (bijv. in een CMS, of in combinatie met andere CSS-methodologieën), biedt dit bestand alle design tokens aan als CSS Custom Properties. Deze variabelen kunnen in elke CSS-stylesheet worden gebruikt.

```css
/* Voorbeeld van CSS variabelen */
:root {
  --color-primary-teal: #00A896;
  --font-size-base: 16px;
  --spacing-4: 16px;
}

.custom-component {
  background-color: var(--color-primary-teal);
  font-size: var(--font-size-base);
  padding: var(--spacing-4);
}
```

## Installatie en Gebruik

Volg deze stappen om het EDS in een nieuw project te gebruiken:

1.  **Plaats de bestanden**: Kopieer de bestanden uit `EDS_Assets.zip` naar de root van uw project.

2.  **Installeer dependencies**: Open een terminal en voer het volgende commando uit om de benodigde development dependencies te installeren:
    ```bash
    npm install
    ```

3.  **Start de build process**: Gebruik het volgende commando om de CSS te compileren en te "watchen" voor wijzigingen tijdens de ontwikkeling:
    ```bash
    npm run dev
    ```
    Dit commando zal `styles.css` als input gebruiken en een `dist/output.css` bestand genereren dat u in uw HTML kunt linken.

4.  **Link de CSS**: Voeg de gecompileerde CSS toe aan de `<head>` van uw HTML-bestand:
    ```html
    <link href="/dist/output.css" rel="stylesheet">
    ```

5.  **Gebruik de stijlen**: U kunt nu de utility classes van Tailwind en de custom component-classes (bijv. `.btn-primary`) in uw HTML gebruiken.

## Overzicht van Design Tokens

Hieronder volgt een samenvatting van de belangrijkste design tokens die zijn gedefinieerd.

### Kleuren

| Categorie       | Kleur           | Hex Code  | Gebruik                                       |
| --------------- | --------------- | --------- | --------------------------------------------- |
| **Primary**     | Teal            | `#00A896` | Primaire merk- en actiekleur                  |
|                 | Blue            | `#007BFF` | Alternatieve primaire actiekleur              |
| **Secondary**   | Dark            | `#2D3A4D` | Navigatie, headers, donkere achtergronden     |
| **Semantic**    | Success (Green) | `#4CAF50` | Successtatussen, validatie, bevestigingen     |
|                 | Warning (Orange)| `#FFA726` | Waarschuwingen, aandachtspunten               |
|                 | Error (Red)     | `#F44336` | Foutmeldingen, destructieve acties            |
| **Neutral**     | Gray Scale      | `#111..#F9F` | Tekst, achtergronden, borders, UI-elementen   |

### Typografie

-   **Font Family**: `Montserrat` is het primaire lettertype voor alle UI-tekst.
-   **Font Weights**: `regular` (400), `medium` (500), `semibold` (600), `bold` (700).
-   **Font Size Scale**: Een schaal van `xs` (12px) tot `4xl` (32px) is gedefinieerd voor hiërarchie.

### Spacing

Het systeem gebruikt een 8px basis-grid, maar de spacing-schaal is gebaseerd op 4px-incrementen voor meer flexibiliteit (`4px`, `8px`, `12px`, `16px`, etc.).

### Andere Tokens

-   **Border Radius**: Een schaal van `sm` (4px) tot `xl` (16px) en `full` voor pill-shapes.
-   **Shadows**: Een set van subtiele schaduwen (`sm`, `md`, `lg`, `xl`) voor diepte.
-   **Breakpoints**: `mobile`, `tablet`, `desktop`, en `wide` voor responsive design.

---

Dit Enterprise Design System biedt een robuuste en flexibele basis voor het bouwen van consistente en hoogwaardige gebruikersinterfaces. Door de principes van design tokens en de kracht van Tailwind CSS te combineren, kunnen ontwikkelingsteams sneller en efficiënter werken.

