# Design Analyse - Geëxtraheerde Informatie

## Kleurenpalet

### Primaire Kleuren
- **Primary Teal**: #00A896 / rgb(0, 168, 150)
- **Secondary Dark**: #2D3A4D / rgb(45, 58, 77)
- **Success Green**: #4CAF50 / rgb(76, 175, 80)
- **Warning Orange**: #FFA726 / rgb(255, 167, 38)
- **Error Red**: #F44336 / rgb(244, 67, 54)

### Secundaire Kleuren
- **Blue (Primary Button)**: #0078FF / #007BFF (blauw voor primaire acties)
- **Light Teal/Cyan**: Gebruikt voor accenten en borders
- **Light Green**: Voor success badges en positieve indicators
- **Light Yellow/Beige**: Voor warning boxes
- **Light Red/Pink**: Voor error boxes

### Neutrale Kleuren
- **Dark Gray (Headers)**: #2D3A4D, #3D4A5D
- **Medium Gray (Text)**: #6B7280, #9CA3AF
- **Light Gray (Backgrounds)**: #F3F4F6, #F9FAFB, #E5E7EB
- **White**: #FFFFFF
- **Border Gray**: #D1D5DB

## Typografie

### Font Family
- **Primary Font**: Montserrat
  - Montserrat Bold (Headings: H1-32px, H2-28px, H3-24px, H4-20px, H5-18px, H6-16px)
  - Montserrat Semibold (Body: 18px-16px, Captions: 12px-14px)
  - Montserrat Regular (Body: 14px-16px, Small: 12px-14px)

### Typografie Schaal
- **H1**: 32px
- **H2**: 28px  
- **H3**: 24px
- **H4**: 20px
- **H5**: 18px
- **H6**: 16px
- **Body**: 16px
- **Small**: 14px
- **Caption**: 12px

## Spacing Scale (8px base)

- **xs**: 4px (0.5rem)
- **sm**: 8px (1rem)
- **md**: 16px (2rem)
- **lg**: 24px (3rem)
- **xl**: 32px (4rem)
- **2xl**: 48px (6rem)

## Component Patronen

### Buttons
- **Primary Button**: Teal background (#00A896), white text, rounded corners
- **Secondary Button**: Outlined, teal border, teal text
- **Button States**: Hover, active, disabled

### Cards
- **Basic Card**: White background, subtle shadow, rounded corners
- **Stat Card**: Colored left border (teal, green, dark, red), large numbers, labels
- **Header/Footer Card**: Teal header, white body
- **Warning Box**: Light yellow background, yellow/orange text
- **Error Box**: Light red/pink background, red text
- **Info Box**: Light teal/cyan background, teal border
- **Accent Border Card**: Top border in accent color

### Forms
- **Input Fields**: White background, gray border, rounded corners, focus state with teal border
- **Labels**: Dark gray, above inputs
- **Validation**: Green for success, red for error

### Tables
- **Header**: Dark gray background (#2D3A4D), white text
- **Rows**: Alternating white/light gray backgrounds
- **Borders**: Light gray dividers

### Status Badges
- **Approved/Betaald**: Green background, green text
- **Pending/In Behandeling**: Yellow/orange background, orange text
- **Rejected/Achterstallig**: Red background, red text
- **Active/Actief**: Light green background, green text
- **Trial**: Light orange background, orange text

### Navigation
- **Sidebar**: Dark gray (#2D3A4D) background, white/gray text
- **Active Menu Item**: Green background (#4CAF50)
- **Top Bar**: White background, teal accents
- **Mobile Bottom Tabs**: Teal background, white icons

### KPI Tiles
- **Large Number Display**: Bold, large font (32px+)
- **Percentage Badge**: Small, rounded, colored background
- **Label**: Small text below number
- **Colored Left Border**: Teal, green, dark, or red

### Notifications
- **Toast Notifications**: 4 states (success-green, info-blue, warning-orange, error-red)
- **Left Border**: Colored accent
- **Background**: Light tinted background matching state

## Layout Grid
- **12-Column Grid System**
- **Responsive Breakpoints**:
  - Mobile: < 768px
  - Tablet: 768px - 1024px
  - Desktop: 1024px - 1280px
  - Large Desktop: > 1280px

## Border Radius
- **Small**: 4px
- **Medium**: 8px
- **Large**: 12px
- **Full**: 9999px (pills/badges)

## Shadows
- **Small**: 0 1px 2px rgba(0, 0, 0, 0.05)
- **Medium**: 0 4px 6px rgba(0, 0, 0, 0.1)
- **Large**: 0 10px 15px rgba(0, 0, 0, 0.1)

## Iconografie
- Gebruikt voor navigatie, acties, en status indicators
- Consistent formaat (16px, 20px, 24px)
- Teal of gray kleuren afhankelijk van context

