import React from 'react';
import PropTypes from 'prop-types';

/**
 * KPI Tile Component
 * 
 * Een component voor het weergeven van Key Performance Indicators (KPI's).
 * Toont een grote waarde met label en optionele badge/percentage.
 * 
 * @component
 * @example
 * <KPITile
 *   value="€94,650"
 *   label="Totaal Verdiend (2025)"
 *   badge="+18.5%"
 *   variant="primary"
 * />
 */
const KPITile = ({
  value,
  label,
  badge,
  badgeVariant = 'success',
  variant = 'primary',
  icon,
  className = '',
  ...props
}) => {
  const baseClasses = 'rounded-lg p-6';
  
  const variantClasses = {
    primary: 'bg-primary-teal text-white',
    success: 'bg-success text-white',
    dark: 'bg-secondary-dark text-white',
    light: 'bg-white text-gray-900 border border-gray-200',
  };
  
  const badgeVariantClasses = {
    success: 'bg-success-100 text-success-700',
    warning: 'bg-warning-100 text-warning-700',
    error: 'bg-error-100 text-error-700',
    neutral: 'bg-gray-100 text-gray-700',
  };
  
  const classes = `
    ${baseClasses}
    ${variantClasses[variant] || variantClasses.primary}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  const isLightVariant = variant === 'light';
  
  return (
    <div className={classes} {...props}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          {label && (
            <p className={`text-sm mb-2 ${isLightVariant ? 'text-gray-500' : 'opacity-90'}`}>
              {label}
            </p>
          )}
          <div className="flex items-baseline space-x-2">
            <p className="text-4xl font-bold">{value}</p>
            {badge && (
              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${badgeVariantClasses[badgeVariant]}`}>
                {badge}
              </span>
            )}
          </div>
        </div>
        {icon && (
          <div className={`flex-shrink-0 ml-4 ${isLightVariant ? 'text-gray-400' : 'opacity-75'}`}>
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};

KPITile.propTypes = {
  /** De hoofdwaarde die wordt weergegeven */
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  /** Label/beschrijving van de KPI */
  label: PropTypes.string,
  /** Badge tekst (bijv. percentage verandering) */
  badge: PropTypes.string,
  /** Variant van de badge */
  badgeVariant: PropTypes.oneOf(['success', 'warning', 'error', 'neutral']),
  /** Visuele variant van de tile */
  variant: PropTypes.oneOf(['primary', 'success', 'dark', 'light']),
  /** Optioneel icon */
  icon: PropTypes.node,
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default KPITile;

