import React from 'react';
import PropTypes from 'prop-types';

/**
 * Badge Component
 * 
 * Een component voor het weergeven van status badges, labels en tags.
 * Ondersteunt verschillende varianten zoals success, warning, error, etc.
 * 
 * @component
 * @example
 * <Badge variant="success">Betaald</Badge>
 * <Badge variant="warning">In Behandeling</Badge>
 */
const Badge = ({
  children,
  variant = 'neutral',
  size = 'medium',
  rounded = true,
  className = '',
  ...props
}) => {
  const baseClasses = 'inline-flex items-center font-medium';
  
  const variantClasses = {
    success: 'bg-success-100 text-success-700',
    warning: 'bg-warning-100 text-warning-700',
    error: 'bg-error-100 text-error-700',
    info: 'bg-info-100 text-info-700',
    neutral: 'bg-gray-100 text-gray-700',
    primary: 'bg-primary-teal/10 text-primary-teal',
  };
  
  const sizeClasses = {
    small: 'px-2 py-0.5 text-xs',
    medium: 'px-3 py-1 text-sm',
    large: 'px-4 py-1.5 text-base',
  };
  
  const roundedClasses = rounded ? 'rounded-full' : 'rounded';
  
  const classes = `
    ${baseClasses}
    ${variantClasses[variant] || variantClasses.neutral}
    ${sizeClasses[size] || sizeClasses.medium}
    ${roundedClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <span className={classes} {...props}>
      {children}
    </span>
  );
};

Badge.propTypes = {
  /** De inhoud van de badge */
  children: PropTypes.node.isRequired,
  /** De visuele variant van de badge */
  variant: PropTypes.oneOf(['success', 'warning', 'error', 'info', 'neutral', 'primary']),
  /** De grootte van de badge */
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  /** Of de badge volledig afgeronde hoeken heeft */
  rounded: PropTypes.bool,
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default Badge;

