import React from 'react';
import PropTypes from 'prop-types';

/**
 * Button Component
 * 
 * Een herbruikbare button component met verschillende varianten en states.
 * Gebaseerd op het Enterprise Design System.
 * 
 * @component
 * @example
 * <Button variant="primary" onClick={handleClick}>
 *   Klik hier
 * </Button>
 */
const Button = ({
  children,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  fullWidth = false,
  onClick,
  type = 'button',
  className = '',
  ...props
}) => {
  const baseClasses = 'inline-flex items-center justify-center font-semibold rounded transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  const variantClasses = {
    primary: 'bg-primary-teal text-white hover:bg-primary-teal/90 focus:ring-primary-teal',
    secondary: 'border-2 border-primary-teal text-primary-teal bg-transparent hover:bg-primary-teal hover:text-white focus:ring-primary-teal',
    success: 'bg-success text-white hover:bg-success-600 focus:ring-success',
    warning: 'bg-warning text-white hover:bg-warning-600 focus:ring-warning',
    error: 'bg-error text-white hover:bg-error-600 focus:ring-error',
    ghost: 'bg-transparent text-primary-teal hover:bg-gray-100 focus:ring-primary-teal',
  };
  
  const sizeClasses = {
    small: 'px-3 py-1.5 text-sm',
    medium: 'px-4 py-2 text-base',
    large: 'px-6 py-3 text-lg',
  };
  
  const disabledClasses = disabled 
    ? 'bg-gray-300 text-gray-500 cursor-not-allowed hover:bg-gray-300' 
    : '';
  
  const widthClasses = fullWidth ? 'w-full' : '';
  
  const classes = `
    ${baseClasses}
    ${variantClasses[variant] || variantClasses.primary}
    ${sizeClasses[size] || sizeClasses.medium}
    ${disabledClasses}
    ${widthClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <button
      type={type}
      className={classes}
      onClick={onClick}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
};

Button.propTypes = {
  /** De inhoud van de button */
  children: PropTypes.node.isRequired,
  /** De visuele variant van de button */
  variant: PropTypes.oneOf(['primary', 'secondary', 'success', 'warning', 'error', 'ghost']),
  /** De grootte van de button */
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  /** Of de button disabled is */
  disabled: PropTypes.bool,
  /** Of de button de volledige breedte moet innemen */
  fullWidth: PropTypes.bool,
  /** Click handler functie */
  onClick: PropTypes.func,
  /** Het type van de button */
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default Button;

