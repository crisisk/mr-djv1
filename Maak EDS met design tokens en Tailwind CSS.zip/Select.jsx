import React from 'react';
import PropTypes from 'prop-types';

/**
 * Select Component
 * 
 * Een dropdown select component met label en error handling.
 * 
 * @component
 * @example
 * <Select
 *   label="Kies een optie"
 *   value={selectedValue}
 *   onChange={handleChange}
 *   options={[
 *     { value: '1', label: 'Optie 1' },
 *     { value: '2', label: 'Optie 2' }
 *   ]}
 * />
 */
const Select = ({
  label,
  value,
  onChange,
  options = [],
  placeholder = 'Selecteer...',
  error,
  helpText,
  required = false,
  disabled = false,
  fullWidth = true,
  className = '',
  id,
  name,
  ...props
}) => {
  const selectId = id || name || `select-${Math.random().toString(36).substr(2, 9)}`;
  
  const baseClasses = 'px-3 py-2 text-base border rounded-lg transition-all focus:outline-none focus:ring-2';
  
  const stateClasses = error
    ? 'border-error focus:ring-error focus:border-transparent'
    : 'border-gray-300 focus:ring-primary-teal focus:border-transparent';
  
  const disabledClasses = disabled
    ? 'bg-gray-100 cursor-not-allowed opacity-60'
    : 'bg-white';
  
  const widthClasses = fullWidth ? 'w-full' : '';
  
  const selectClasses = `
    ${baseClasses}
    ${stateClasses}
    ${disabledClasses}
    ${widthClasses}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className={fullWidth ? 'w-full' : ''}>
      {label && (
        <label
          htmlFor={selectId}
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {label}
          {required && <span className="text-error ml-1">*</span>}
        </label>
      )}
      <select
        id={selectId}
        name={name}
        value={value}
        onChange={onChange}
        disabled={disabled}
        required={required}
        className={selectClasses}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={error ? `${selectId}-error` : helpText ? `${selectId}-help` : undefined}
        {...props}
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && (
        <p id={`${selectId}-error`} className="text-sm text-error mt-1">
          {error}
        </p>
      )}
      {helpText && !error && (
        <p id={`${selectId}-help`} className="text-sm text-gray-500 mt-1">
          {helpText}
        </p>
      )}
    </div>
  );
};

Select.propTypes = {
  /** Label voor het select veld */
  label: PropTypes.string,
  /** Geselecteerde waarde */
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  /** Change handler functie */
  onChange: PropTypes.func,
  /** Array van opties */
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      label: PropTypes.string.isRequired,
    })
  ).isRequired,
  /** Placeholder tekst */
  placeholder: PropTypes.string,
  /** Error bericht */
  error: PropTypes.string,
  /** Help tekst */
  helpText: PropTypes.string,
  /** Of het veld verplicht is */
  required: PropTypes.bool,
  /** Of het veld disabled is */
  disabled: PropTypes.bool,
  /** Of het veld de volledige breedte moet innemen */
  fullWidth: PropTypes.bool,
  /** Extra CSS classes */
  className: PropTypes.string,
  /** ID van het select element */
  id: PropTypes.string,
  /** Name attribuut */
  name: PropTypes.string,
};

export default Select;

