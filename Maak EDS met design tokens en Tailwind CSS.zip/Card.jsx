import React from 'react';
import PropTypes from 'prop-types';

/**
 * Card Component
 * 
 * Een veelzijdige card component met optionele header, body en footer.
 * Ondersteunt verschillende varianten zoals stat cards met accent borders.
 * 
 * @component
 * @example
 * <Card>
 *   <Card.Header>Card Title</Card.Header>
 *   <Card.Body>Card content goes here.</Card.Body>
 *   <Card.Footer>Footer content</Card.Footer>
 * </Card>
 */
const Card = ({
  children,
  variant = 'default',
  accentColor,
  className = '',
  ...props
}) => {
  const baseClasses = 'bg-white rounded-lg shadow-md overflow-hidden';
  
  const variantClasses = {
    default: '',
    bordered: 'border border-gray-200',
    elevated: 'shadow-lg',
  };
  
  const accentClasses = accentColor ? 'border-l-4' : '';
  
  const accentColorMap = {
    teal: 'border-l-primary-teal',
    green: 'border-l-success',
    dark: 'border-l-secondary-dark',
    red: 'border-l-error',
    blue: 'border-l-primary-blue',
    warning: 'border-l-warning',
  };
  
  const classes = `
    ${baseClasses}
    ${variantClasses[variant] || ''}
    ${accentClasses}
    ${accentColor ? accentColorMap[accentColor] || '' : ''}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
};

/**
 * Card Header Component
 */
const CardHeader = ({
  children,
  variant = 'default',
  className = '',
  ...props
}) => {
  const baseClasses = 'px-6 py-4 font-semibold';
  
  const variantClasses = {
    default: 'bg-gray-50 border-b border-gray-200 text-gray-900',
    primary: 'bg-primary-teal text-white',
    dark: 'bg-secondary-dark text-white',
  };
  
  const classes = `
    ${baseClasses}
    ${variantClasses[variant] || variantClasses.default}
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
};

/**
 * Card Body Component
 */
const CardBody = ({
  children,
  className = '',
  ...props
}) => {
  const classes = `px-6 py-4 ${className}`.trim();
  
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
};

/**
 * Card Footer Component
 */
const CardFooter = ({
  children,
  className = '',
  ...props
}) => {
  const classes = `px-6 py-4 bg-gray-50 border-t border-gray-200 ${className}`.trim();
  
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
};

Card.Header = CardHeader;
Card.Body = CardBody;
Card.Footer = CardFooter;

Card.propTypes = {
  /** De inhoud van de card */
  children: PropTypes.node.isRequired,
  /** De visuele variant van de card */
  variant: PropTypes.oneOf(['default', 'bordered', 'elevated']),
  /** Accent kleur voor de linker border */
  accentColor: PropTypes.oneOf(['teal', 'green', 'dark', 'red', 'blue', 'warning']),
  /** Extra CSS classes */
  className: PropTypes.string,
};

CardHeader.propTypes = {
  children: PropTypes.node.isRequired,
  variant: PropTypes.oneOf(['default', 'primary', 'dark']),
  className: PropTypes.string,
};

CardBody.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

CardFooter.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

export default Card;

