import React from 'react';
import PropTypes from 'prop-types';

/**
 * TopBar Component
 * 
 * Een top navigatie bar met breadcrumbs, zoekfunctie en user menu.
 * 
 * @component
 * @example
 * <TopBar>
 *   <TopBar.Left>
 *     <Breadcrumb items={breadcrumbItems} />
 *   </TopBar.Left>
 *   <TopBar.Right>
 *     <NotificationIcon />
 *     <UserMenu />
 *   </TopBar.Right>
 * </TopBar>
 */
const TopBar = ({
  children,
  className = '',
  ...props
}) => {
  const classes = `
    bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <header className={classes} {...props}>
      {children}
    </header>
  );
};

/**
 * TopBar Left Section
 */
const TopBarLeft = ({
  children,
  className = '',
  ...props
}) => {
  return (
    <div className={`flex items-center flex-1 ${className}`.trim()} {...props}>
      {children}
    </div>
  );
};

/**
 * TopBar Right Section
 */
const TopBarRight = ({
  children,
  className = '',
  ...props
}) => {
  return (
    <div className={`flex items-center space-x-4 ${className}`.trim()} {...props}>
      {children}
    </div>
  );
};

TopBar.Left = TopBarLeft;
TopBar.Right = TopBarRight;

TopBar.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

TopBarLeft.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

TopBarRight.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

export default TopBar;

