import React from 'react';
import PropTypes from 'prop-types';

/**
 * SearchBar Component
 * 
 * Een zoekbalk component met icon en optionele suggesties.
 * 
 * @component
 * @example
 * <SearchBar
 *   placeholder="Zoek producten, certificaten, leveranciers..."
 *   value={searchQuery}
 *   onChange={handleSearch}
 * />
 */
const SearchBar = ({
  value,
  onChange,
  onSubmit,
  placeholder = 'Zoeken...',
  suggestions = [],
  onSuggestionClick,
  showSuggestions = false,
  className = '',
  ...props
}) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSubmit) {
      onSubmit(value);
    }
  };
  
  return (
    <div className={`relative ${className}`.trim()}>
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg
              className="h-5 w-5 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
          <input
            type="text"
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="w-full pl-10 pr-4 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-teal focus:border-transparent transition-all"
            {...props}
          />
        </div>
      </form>
      
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-10 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-64 overflow-y-auto">
          {suggestions.map((suggestion, index) => (
            <div
              key={index}
              onClick={() => onSuggestionClick && onSuggestionClick(suggestion)}
              className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
            >
              <div className="font-medium text-gray-900">{suggestion.title}</div>
              {suggestion.subtitle && (
                <div className="text-sm text-gray-500">{suggestion.subtitle}</div>
              )}
              {suggestion.badge && (
                <span className="inline-block mt-1 px-2 py-0.5 text-xs font-medium bg-info-50 text-info-700 rounded">
                  {suggestion.badge}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

SearchBar.propTypes = {
  /** Huidige zoekwaarde */
  value: PropTypes.string,
  /** Change handler functie */
  onChange: PropTypes.func,
  /** Submit handler functie */
  onSubmit: PropTypes.func,
  /** Placeholder tekst */
  placeholder: PropTypes.string,
  /** Array van suggesties */
  suggestions: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      subtitle: PropTypes.string,
      badge: PropTypes.string,
    })
  ),
  /** Callback wanneer een suggestie wordt geklikt */
  onSuggestionClick: PropTypes.func,
  /** Of suggesties getoond moeten worden */
  showSuggestions: PropTypes.bool,
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default SearchBar;

