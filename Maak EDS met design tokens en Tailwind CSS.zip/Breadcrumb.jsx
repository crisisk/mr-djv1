import React from 'react';
import PropTypes from 'prop-types';

/**
 * Breadcrumb Component
 * 
 * Een breadcrumb navigatie component voor hiërarchische navigatie.
 * 
 * @component
 * @example
 * <Breadcrumb
 *   items={[
 *     { label: 'Home', href: '/' },
 *     { label: 'Dashboard', href: '/dashboard' },
 *     { label: 'Settings' }
 *   ]}
 * />
 */
const Breadcrumb = ({
  items = [],
  separator = '/',
  className = '',
  ...props
}) => {
  if (!items || items.length === 0) return null;
  
  const classes = `
    flex items-center space-x-2 text-sm text-gray-500
    ${className}
  `.trim().replace(/\s+/g, ' ');
  
  return (
    <nav className={classes} aria-label="Breadcrumb" {...props}>
      <ol className="flex items-center space-x-2">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          
          return (
            <li key={index} className="flex items-center">
              {item.href && !isLast ? (
                <a
                  href={item.href}
                  className="hover:text-primary-teal transition-colors"
                >
                  {item.label}
                </a>
              ) : (
                <span className={isLast ? 'text-gray-900 font-medium' : ''}>
                  {item.label}
                </span>
              )}
              {!isLast && (
                <span className="mx-2 text-gray-400" aria-hidden="true">
                  {separator}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

Breadcrumb.propTypes = {
  /** Array van breadcrumb items */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      href: PropTypes.string,
    })
  ).isRequired,
  /** Separator karakter tussen items */
  separator: PropTypes.string,
  /** Extra CSS classes */
  className: PropTypes.string,
};

export default Breadcrumb;

